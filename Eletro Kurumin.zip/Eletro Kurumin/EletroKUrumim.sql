-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`categoria` (
  `idCategoria` INT(11) NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `descricao` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idCategoria`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

-- -----------------------------------------------------
-- Table `mydb`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`usuario` (
  `idUsuario` INT(11) NOT NULL,
  `nome` VARCHAR(100) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `Palavra_passe` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idUsuario`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

-- -----------------------------------------------------
-- Table `mydb`.`Componente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Componente` (
  `idComponente` INT NOT NULL,
  `nome` VARCHAR(45) NOT NULL,
  `descricao` VARCHAR(120) NOT NULL,
  `preco` DECIMAL(10,2) NOT NULL,
  `quantidade_estoque` INT NOT NULL,
  `categoria_idCategoria` INT(11) NOT NULL,
  `usuario_idUsuario` INT(11) NOT NULL,
  PRIMARY KEY (`idComponente`),
  INDEX `fk_Componente_categoria1_idx` (`categoria_idCategoria` ASC),
  INDEX `fk_Componente_usuario1_idx` (`usuario_idUsuario` ASC),
  CONSTRAINT `fk_Componente_categoria1`
    FOREIGN KEY (`categoria_idCategoria`)
    REFERENCES `mydb`.`categoria` (`idCategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Componente_usuario1`
    FOREIGN KEY (`usuario_idUsuario`)
    REFERENCES `mydb`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `mydb`.`movimentacao`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`movimentacao` (
  `idmovimentacao` INT NOT NULL,
  `data_movimentaco` DATETIME NOT NULL,
  `tipo` VARCHAR(45) NOT NULL,
  `quantidade` INT NOT NULL,
  `justificativa` VARCHAR(170) NOT NULL,
  `usuario_idUsuario` INT(11) NOT NULL,
  `Componente_idComponente` INT NOT NULL,
  PRIMARY KEY (`idmovimentacao`),
  INDEX `fk_movimentacao_usuario_idx` (`usuario_idUsuario` ASC),
  INDEX `fk_movimentacao_Componente1_idx` (`Componente_idComponente` ASC),
  CONSTRAINT `fk_movimentacao_usuario`
    FOREIGN KEY (`usuario_idUsuario`)
    REFERENCES `mydb`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_movimentacao_Componente`eletro kurumin`1`
    FOREIGN KEY (`Componente_idComponente`)
    REFERENCES `mydb`.`Componente` (`idComponente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;